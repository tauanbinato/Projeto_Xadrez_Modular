/***************************************************************************
*  $MCI M�dulo de implementa��o: GTB Gerar a tabela de strings residentes
*
*  Arquivo gerado:              GeraTab.C
*  Letras identificadoras:      GTB
*
*  Nome da base de software:    Gerar e acessar tabelas de strings
*  Arquivo da base de software: C:\AUTOTEST\PROJETOS\TABELA.BSW
*
*  Projeto: INF 1301/1628 - Exemplos
*  Gestor:  LES/DI/PUC-Rio
*  Autores: avs Arndt von Staa
*
*  $HA Hist�rico de evolu��o:
*     Vers�o  Autor    Data     Observa��es
*     1        avs  20/11/2004  Inicio desenvolvimento
*
*  $ED Descri��o do m�dulo
*     Gera a tabela de strings residente em mem�ria. A gera��o se d�
*     a partir de um ou mais arquivos de especifica��o de strings
*     listados em um arquivo contendo a lista de arquivos a processar.
*
*     Os arquivos de especifica��o de strings servem a um duplo prop�sito:
*     gerar a tabela residente e gerar os arquivos defini��o contendo
*     a lista de constantes simb�licas a serem utilizadas nos m�dulos
*     de implementa��o nas chamadas � fun��o de recupera��o de strings.
*
*     Esta ferramenta � parte do conjunto de ferramentas que visa agilizar
*     a internacionaliza��o de programas. Os outros dois componentes
*     desse conjunto s�o:
*
*     GERADEF  - Programa gerador de tabelas de defini��o: gera as
*                constantes simb�licas a serem utilizados nos m�dulos
*                de implementa��o
*
*     TABSTR   - m�dulo de acesso � tabela de strings.
*
*  $EIU Interface com o usu�rio pessoa
*     Est�o definidos os par�metros de linha de comando:
*
*      /L<nome arquivo lista>   obrigat�rio
*         este arquivo cont�m a lista de arquivos contendo defini��es
*         de strings e dever�o figurar na tabela. A exten�o default
*         desse arquivo �   .lista
*
*      /T<nome arquivo tabela>     opcional
*         este ser� o arquivo gerado. Conter� a tabela dos strings
*         extra�dos dos arquivos enumerados no arquivo lista.
*         Caso este par�metro n�o seja fornecido, o arquivo gerado
*         ter� o mesmo nome do arquivo lista, sendo que � susbtitu�do
*         o nome de extens�o pelo nome default da tabela.
*         O nome defaukt do arquivo tabela �   .tabstr
*
*      /h /H /? geram o help do comando   GeraTab
*
*     O arquivo lista cont�m zero ou mais linhas. Cada linha pode ser:
*
*       em branco             - � ignorada
*       // na primeira coluna - � coment�rio ignorado
*       <nome arquivo string> - identifica um arquivo contendo as
*                               especifica��es de strings a serem inclu�dos
*                               na tabela. A extens�o default �  .defstr
*
*     Os arquivos string cont�m zero ou mais linhas. Cada linha pode ser:
*
*       em branco             - � ignorada
*       // na primeira coluna - � coment�rio ignorado
*       especifica��o de string
*
*     Uma linha de especifica��o de string tem o formato:
*
*       NomeString    idString   String
*
*          NomeString - � um nome satisfazendo a sintaxe C de uma constante
*                       simb�lica. Este nome ser� o identificador simb�lico
*                       do string. A ferramenta GeraDef produz um arquivo
*                       contendo a tabela de defini��o, contendo as
*                       declara��es simb�licas dos strings. Essa ferramenta
*                       gera um arquivo defini��o para cada arquivo string
*
*          idString   - � o valor da constante simb�lica. Os strings e
*                       os idString devem formar uma rela��o um para um.
*                       Para impedir a ocorr�ncia de idString iguais
*                       em diferentes Arquivos String, sugere-se a ado��o
*                       do seguinte padr�o de programa��o:
*
*                       - para cada m�dulo existir� no m�ximo um Arquivo
*                         String. Caso o m�dulo n�o defina string, n�o
*                         ser� necess�rio criar um Arquivo String
*                       - para cada m�dulo � definido um n�mero identificador
*                         �nico. A diferen�a de n�meros identificadores
*                         de m�dulos consecutivos deve ser sempre maior do
*                         que o n�mero de strings definidos no m�dulo
*                         de menor identificador. Sugere-se dar incrementos
*                         de pelo menos 50.
*                       - os idStrings s�o gerados consecutivamente a partir
*                         do n�mero identificador do m�dulo
*
*           String    - � um string no formato C. Valem todos os escapes
*                       padr�o de C.
*
*  $EIM Interface com outros m�dulos
*     O arquivo tabela gerado possui:
*
*     - um conjunto de declara��es de tipo (struct) utilizados para
*       acessar os elementos da tabela.
*
*     - uma tabela de pesquisa a partir da qual se localiza o string procurado
*
*     - uma ou mais tabelas de armazenamento cada qual contendo um ou mais
*       strings. As tabelas de armazenamento s�o compostas por m�ltiplos
*       strings e s�o limitadas quanto ao comprimento
*
*     - um vetor de refer�ncia �s tabelas de armazenamento.
*
*     Dado um idString procura-se o seu descritor na tabela de pesquisa.
*     Cada elemento da tabela de pesquisa indica o �ndice do elemento no
*     vetor de refer�ncias que cont�m as refer�ncias das tabelas de
*     armazenamento. O elemento da tabela de pesquisa cont�m ainda o offset
*     do string dentro da correspondente tabela de armazenamento.
*
*     Todas a vari�veis s�o declaradas static e assume-se que ser�o utilizadas
*     como globais encapsuladas.
*
*     A tabela ser� inclu�da no m�dulo TabStr. Esse m�dulo possui fun��es
*     que permitem extrair os strings contidos na tabela.
*
***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <malloc.h>

#define DIM_ID_PARM              2
#define DIM_BUFFER             512
#define DIM_NOME_ARQUIVO       512
#define DIM_NOME_STRING         34
#define DIM_STRING             256
#define DIM_STRINGAO          1023

#define LIMPA_FIM                1
#define LIMPA_INIC               2
#define CHARS_FIM                " \r\n\t"
#define ID_COMENTARIO            "//"

#define SEPARADOR_EXTENSAO       '.'
#define SEPARADOR_DIRETORIO      '\\'

const char ExtArquivoLista[ ]  = ".lista" ;
const char ExtArquivoString[ ] = ".espstr" ;
const char ExtArquivoTabela[ ] = ".tab" ;

char NomeArquivoTabelaDefault[ ] = "TabelaString.tab" ;
char NomeArquivoStringDefault[ ] = "DefinicaoDefault.espstr" ;
char NomeArquivoEstatisticas[ ]  = "TabelaString.txt" ;

const char CMD_OFFSET[ ]       = "<Offset>" ;

const char idParmArquivoLista[ ] = "/L" ;
const char idParmGerado[ ]       = "/T" ;
const char idParmAuxilio1[ ]     = "/h" ;
const char idParmAuxilio2[ ]     = "/H" ;
const char idParmAuxilio3[ ]     = "/?" ;

/***********************************************************************
*
*  $TC Tipo de dados: GT C�digos de t�rmino de processamento
*
*
***********************************************************************/

   typedef enum {

         CodigoOK ,
               /* Executou corretamente o programa */

         CodigoAuxilio ,
               /* Foi solicitado aux�lio */

         CodigoArquivoNaoAbre ,
               /* Arquivo n�o abre */

         CodigoNaoArquivoLista ,
               /* Arquivo lista de arquivos n�o foi definido */

         CodigoParametroDuplo ,
               /* Par�metro duplicado */

         CodigoErroProcessamento ,
               /* Erro de processamento */

         CodigoErroParametro
               /* Par�metro errado */

   } tpCodigoErro ; ;

/***********************************************************************
*
*  $TC Tipo de dados: GT C�digos de retorno de fun��es
*
*
***********************************************************************/

   typedef enum {

         CondRetOK ,
               /* Fun��o executou correto */

         CondRetFimArq ,
               /* Fim de arquivo de leitura */

         CondRetOverflow ,
               /* Linha lida � longa demais para o buffer */

         CondRetErro
               /* Erro de leitura de arquivo */

   } tpCondRet ;

/***********************************************************************
*
*  $TC Tipo de dados: GT Elemento da lista de arquivos
*
*
*  $ER Requisitos assegurados pelo tipo
*     Os elementos de lista devem ter os mesmos tr�s primeiros
*     atributos pois est� sendo simulada heran�a.
*
***********************************************************************/

   typedef struct tgElemArquivo {

         struct tgElemArquivo * pAnt ;
               /* Elemento antecessor */

         struct tgElemArquivo * pProx ;
               /* Elemento sucessor */

         char NomeArquivo[ DIM_NOME_ARQUIVO ] ;
               /* Nome do arquivo */

   } tpElemArquivo ;

/***********************************************************************
*
*  $TC Tipo de dados: GT Elemento da lista de strings
*
*
***********************************************************************/

   typedef struct tgElemString {

         struct tgElemString * pAnt ;
               /* Elemento antecessor na lista */

         struct tgElemString * pProx ;
               /* Elemento sucessor na lista */

         char   String[ DIM_STRING ] ;
               /* Valor do string */

         long   idString ;
               /* Identificador do string */

         int    tamString ;
               /* Tamanho do string */

         int    inxString ;
               /* �ndice da tabela de armazenamento */

         int    offsetString ;
               /* Offset do string dentro da tabela de armazenamento */

   } tpElemString ;

/*****  Dados encapsulados no m�dulo  *****/

      static tpElemArquivo * pOrigemListaArquivos = NULL ;
            /* �ncora da lista de arquivos de defini��o */

      static tpElemString * pOrigemListaStrings = NULL ;
            /* �ncora da lista de strings */

      static char NomeArquivoTabela[ DIM_BUFFER ] ;
            /* Arquivo tabela */

      static char NomeArquivoLista[ DIM_BUFFER ] ;
            /* Arquivo lista */

      static int ContaArquivosString ;
            /* Contador de arquivos de especifica��o de strings */

      static int ContaEspecString ;
            /* Contador de n�mero de especifica��es de strings registrados */

      static int ContaStringao ;
            /* Contador de n�mero de string�es gerados */

      static int ContaErros ;
            /* Contador de erros de sintaxe encontrados */

/***** Prot�tipos das fun��es encapuladas no m�dulo *****/

   static tpCondRet ObterTodasListasDados( ) ;

   static void ProcessarArquivoStrings( char * NomeArquivoString ) ;

   static void GerarTabelaStrings( ) ;

   static void GerarEstatisticas( ) ;

   static tpElemString * CriarElemListaString( long   idStringParm ,
                                               int    tamStringParm ,
                                               char * StringParm ) ;

   static tpElemArquivo * CriarElemListaArquivo( char * NomeArquivoParm ) ;

   static int RegistrarArquivo( char * NomeArquivo ) ;

   static int ObterInxExtensao( char * NomeArquivo ) ;

   static tpCondRet LerTrimmed( FILE * pArqLe    ,
                                char * pBuffer   ,
                                int    dimBuffer ,
                                int    Modo       ) ;

/*****  C�digo das fun��es exportadas pelo m�dulo  *****/


/***********************************************************************
*
*  $FC Fun��o: GTB Processar linha de comando de gerar tabela de strings
*
*  $ED Descri��o da fun��o
*     Gera a tabela de strings residentes em mem�ria.
*     A tabela � gerada a partir dos arquivos *.def identificados
*     no arquivo ListaArquivos.def passado por par�metro
*
***********************************************************************/

   int main( int numParametros , char ** vtParametros  )
   {

      tpCodigoErro CodigoErro = CodigoOK ;

      char ParametroCorr[ DIM_BUFFER ] ;

      int i ;

      int numParmLista = 0 ;

      int numParmTabela = 0 ;

      /* Apresentar identifica��o do programa */

         printf( "\nGeraTab - Gerar a tabela de strings residentes em mem�ria" ) ;
         printf( "\n          LES/DI/PUC-Rio, vers�o 1, 21/11/2004\n" ) ;

      /* Processar par�metros de linha de comando */

         ContaArquivosString = 0 ;
         ContaEspecString    = 0 ;
         ContaStringao       = 0 ;
         ContaErros          = 0 ;

         /* Obter todos par�metros de linha de comando */

            NomeArquivoLista[  0 ] = 0 ;
            ParametroCorr[     0 ] = 0 ;

            strcpy( NomeArquivoTabela , NomeArquivoTabelaDefault ) ;

            for ( i = 1 ; i < numParametros ; i ++ ) {

            /* Obter parametro corrente */

               strcpy( ParametroCorr , vtParametros[ i ] ) ;

            /* Processar par�metro arquivo lista de arquivos */

               if ( memcmp( ParametroCorr , idParmArquivoLista , DIM_ID_PARM ) == 0 )
               {

                  if ( numParmLista > 0 )
                  {
                     CodigoErro = CodigoParametroDuplo ;
                     printf( "\n>>> Arquivo lista %s definido m�ltiplas vezes." , ParametroCorr ) ;
                     ContaErros ++ ;

                  } else {
                     numParmLista ++ ;
                     strcpy( NomeArquivoLista , & ParametroCorr[ DIM_ID_PARM ] ) ;

                     if ( ObterInxExtensao( NomeArquivoLista ) == - 1 )
                     {
                        strcat( NomeArquivoLista , ExtArquivoLista ) ;
                     } /* if */
                  } /* if */

               } /* fim ativa: Processar par�metro arquivo lista de arquivos */

            /* Processar par�ametro arquivo a ser gerado */

               else if ( memcmp( ParametroCorr , idParmGerado , DIM_ID_PARM ) == 0 )
               {

                  if ( numParmTabela > 0 )
                  {
                     CodigoErro = CodigoParametroDuplo ;
                     printf( "\n>>> Arquivo tabela %s definido m�ltiplas vezes." , ParametroCorr ) ;
                     ContaErros ++ ;

                  } else
                  {
                     numParmTabela ++ ;
                     strcpy( NomeArquivoTabela , & ParametroCorr[ DIM_ID_PARM ] ) ;
                  } /* if */

               } /* fim ativa: Processar par�ametro arquivo a ser gerado */

            /* Processar par�metro aux�lio */

               else if ( ( memcmp( ParametroCorr , idParmAuxilio1 , DIM_ID_PARM ) == 0 )
                      || ( memcmp( ParametroCorr , idParmAuxilio2 , DIM_ID_PARM ) == 0 )
                      || ( memcmp( ParametroCorr , idParmAuxilio3 , DIM_ID_PARM ) == 0 )
                      || ( ParametroCorr[ 0 ] == '?' ))
               {

                  CodigoErro = CodigoAuxilio ;

               } /* fim ativa: Processar par�metro aux�lio */

            /* Tratar par�metro errado */

               else
               {

                  printf( "\n>>> Par�metro errado: %s" , ParametroCorr ) ;
                  CodigoErro = CodigoErroParametro ;
                  ContaErros ++ ;

               } /* fim ativa: Tratar par�metro errado */

            } /* fim repete: Obter todos par�metros de linha de comando */

         /* Controlar corretude dos par�metros */

            if ( numParmLista == 0 )
            {
               CodigoErro = CodigoNaoArquivoLista ;
               printf( "\n>>> O arquivo lista n�o foi definido." ) ;
               ContaErros ++ ;
            } /* if */

            if ( ObterInxExtensao( NomeArquivoTabela ) == -1 )
            {
               strcat( NomeArquivoTabela , ExtArquivoTabela ) ;
            } /* if */

         /* Exibir help de uso do programa */

            if( CodigoErro != CodigoOK )
            {

               printf( "\n\nSintaxe da linha de comando: " ) ;
               printf( "\n geratab { /L<Arquivo Lista> | /T<Arquivo Tabela> | /h | /H | /? | ? }" ) ;
               printf( "\n" ) ;
               printf( "\n   <Arquivo Lista> E' o nome de um arquivo que contem a lista" ) ;
               printf( "\n         dos nomes de todos os arquivos de especificacao de" ) ;
               printf( "\n         strings a serem processados" ) ;
               printf( "\n   <Arquivo Tabela> parametro opcional, e' o nome do arquivo" ) ;
               printf( "\n         tabela de strings a ser gerado." ) ;
               printf( "\n As extens�es default sao: " ) ;
               printf( "\n   lista  - para o arquivo que contem a lista de arquivos a processar" ) ;
               printf( "\n   espstr - para os arquivos contendo strings." ) ;
               printf( "\n   tabstr - para o arquivo tabela a ser gerado." ) ;
               printf( "\n Nao sendo fornecido o nome do arquivo a ser gerado, a tabela " ) ;
               printf( "\n sera gerada no arquivo tabelastring.tab " ) ;
               printf( "\n\n" ) ;

               GerarEstatisticas( ) ;

               if ( CodigoErro != CodigoAuxilio )
               {
                  return 4 ;
               } /* if */

               return 0 ;

            } /* fim ativa: Exibir help de uso do programa */

      /* Obter as listas de todos arquivos e todos os strings */

         #ifdef _DEBUG
            Todos os par�metros est�o OK, e n�o tem solicita��o de aux�lio
         #endif

         ObterTodasListasDados( ) ;

      /* Gerar o arquivo de strings */

         if ( ContaErros == 0 )
         {

            GerarTabelaStrings( ) ;

         } /* fim ativa: Gerar o arquivo de strings */

      /* Terminar o programa */

         GerarEstatisticas( ) ;

         if ( ContaErros > 0 )
         {
            CodigoErro = CodigoErroProcessamento ;
            printf( "\n\n>>> Foram encontrados %i erros.\n\n" ,
                    ContaErros ) ;
            return 4 ;
         } /* if */

         printf( "\n\n" ) ;

         return 0 ;

   } /* Fim fun��o: GTB Processar linha de comando de gerar tabela de strings */


/*****  C�digo das fun��es encapsuladas no m�dulo  *****/


/***********************************************************************
*
*  $FC Fun��o: GT Obter todas as listas
*
*  $ED Descri��o da fun��o
*     Percorre o arquivo lista.
*     Para cada arquivo encontrado extrai todos os strings especificados.
*     Gera a lista de todos os strings a serem inseridos na tabela
*
*  $EAE Assertivas de sa�da asseguradas
*     A lista de arquivos de especifica��o de strings e a lista de strings
*     foram criadas.
*     Independentemente de como termina a execu��o as listas estar�o corretas.
*     Caso n�o tenha ocorrido erro, as listas est�o completas.
*     Caso tenha ocorrido erro as listas podera�o estar incompletas.
*     ContaErros conta o n�mero de erros encontrados, 0 se nenhum.
*
***********************************************************************/

   tpCondRet ObterTodasListasDados( )
   {

      FILE * pArquivoLista = NULL ;

      tpCondRet CondRet    = CondRetOK ;

      char LinhaArquivoString[ DIM_BUFFER ] ;
      char NomeArquivoString[ DIM_BUFFER ] ;

      /* Iniciar as listas */

         pOrigemListaStrings  = CriarElemListaString( 0 , 0 , "||" ) ;
         pOrigemListaArquivos = CriarElemListaArquivo( "||" ) ;

      /* Processar arquivo de especifica��o de strings default */

         ProcessarArquivoStrings( NomeArquivoStringDefault ) ;

      /* Abrir arquivo lista de arquivos de especifica��o de strings */

         pArquivoLista = fopen( NomeArquivoLista , "r" ) ;

         if ( pArquivoLista == NULL )
         {
            printf( "\n>>> Arquivo lista  %s  n�o existe." , NomeArquivoLista ) ;
            ContaErros ++ ;
            return CondRetErro ;
         } /* if */

      /* Processar todos os arquivos de defini��o de string */

         LinhaArquivoString[ 0 ] = 0 ;

         CondRet = LerTrimmed( pArquivoLista , LinhaArquivoString ,
                               DIM_BUFFER - 1 , LIMPA_INIC | LIMPA_FIM ) ;

         while ( CondRet == CondRetOK ) {

         /* Processar arquivo de especifica��o de strings */

            if ( sscanf( LinhaArquivoString ,
                         "#include \"%[^\"]s\"" , NomeArquivoString ) == 1 )
            {
               ProcessarArquivoStrings( NomeArquivoString ) ;
            } else
            {
               printf( "\n>>> Linha arquivo string errada: %s" , LinhaArquivoString ) ;
               ContaErros ++ ;
            } /* if */

         /* Obter pr�ximo nome de arquivo de defini��o */

            CondRet = LerTrimmed( pArquivoLista , LinhaArquivoString ,
                                  DIM_BUFFER - 1 , LIMPA_INIC | LIMPA_FIM ) ;

         } /* fim repete: Processar todos os arquivos de defini��o de string */

         if ( CondRet != CondRetFimArq )
         {
            printf( "\n>>> Litura do arquivo lista % cancelada." ,
                    NomeArquivoLista ) ;
            ContaErros ++ ;
         } /* if */

         fclose( pArquivoLista ) ;

      /* Controlar erros de gera��o */

         if ( ContaEspecString == 0 )
         {
            printf( "\n>>> Nenhum string foi encontrado" ) ;
            ContaErros ++ ;
         } /* if */

      return CondRetOK ;

   } /* Fim fun��o: GT Obter todas as listas */


/***********************************************************************
*
*  $FC Fun��o: GT Extrair todos os strings de arquivo de defini��o de strings
*
***********************************************************************/

   void ProcessarArquivoStrings( char * NomeArquivoString )
   {

      FILE * pArquivoString = NULL ;

      long OffsetLido = 0 ;

      char LinhaString[ DIM_BUFFER ] ;

      char NomeConstante[ DIM_NOME_STRING ] ;
      char StringLido[ DIM_STRING ] ;

      int  TemErro    = 1 ;
      int  tamString  = 0 ;

      tpCondRet CondRet = CondRetErro ;

      int  numLidos     = -1 ;
      long idStringLido = -1 ;

      int ContaCh    = 0 ;

      enum
      {
         EstadoInicial ,
         EstadoNormal ,
         EstadoEscape ,
         EstadoOctal ,
         EstadoHexadecimal ,
         EstadoErro = 99
      } Estado = EstadoErro ;

      int inxCh      = 1 ;

      tpElemString * pStringNovo = NULL ;
      tpElemString * pStringCorr = NULL ;

      /* Abrir arquivo de especifica��o de strings */

         if ( ObterInxExtensao( NomeArquivoString ) == -1 )
         {
            strcat( NomeArquivoString , ExtArquivoString ) ;
         } /* if */

         if ( !RegistrarArquivo( NomeArquivoString ))
         {
            return ;
         } /* if */

         pArquivoString = fopen( NomeArquivoString , "r" ) ;

         if ( pArquivoString == NULL )
         {
            printf( "\n>>> Arquivo  %s  n�o existe." , NomeArquivoString ) ;
            ContaErros ++ ;
            return ;

         } /* if */

         printf( "\n  Arquivo string:  %s" , NomeArquivoString ) ;
         ContaArquivosString ++ ;

      /* Ler offset de idString */

         CondRet = LerTrimmed( pArquivoString , LinhaString ,
                               DIM_BUFFER - 1 , LIMPA_INIC | LIMPA_FIM ) ;
         if ( CondRet != CondRetOK )
         {
            printf( "\n>>> Arquivo  %s  vazio." , NomeArquivoString ) ;
            ContaErros ++ ;
            return ;
         } /* if */

         numLidos = sscanf( LinhaString , " %s %li" ,
                            StringLido , &OffsetLido ) ;

         if ( ( numLidos != 2 )
           || ( strcmp( StringLido , CMD_OFFSET ) != 0 ))
         {
            printf( "\n>>> Arquivo nao inicia com %s: %s" ,
                    CMD_OFFSET , LinhaString ) ;
            ContaErros ++ ;
            OffsetLido = 0 ;
         } /* if */

      /* Obter todos os strings do arquivo corrente */

         CondRet = LerTrimmed( pArquivoString , LinhaString ,
                               DIM_BUFFER - 1 , LIMPA_INIC | LIMPA_FIM ) ;

         while ( CondRet == CondRetOK ) {

         /* Ler especifica��o v�lida */

            numLidos = sscanf( LinhaString , " %s %li %[^\n]" ,
                               NomeConstante , &idStringLido , StringLido ) ;

            TemErro   = 0 ;
            tamString = strlen( StringLido ) ;

            if ( ( numLidos != 3 )
              || ( tamString + 1 > DIM_STRING )
              || ( StringLido[ 0 ] != '\"' )
              || ( StringLido[ tamString - 1 ] != '\"' ))
            {
               TemErro = 1 ;
               printf( "\n>>> Especificacao de string errada: %s" , LinhaString ) ;
               ContaErros ++ ;
            } /* if */

         /* Processar linha de especifica��o */

            if ( !TemErro )
            {

               inxCh   = 0 ;
               ContaCh = 0 ;
               Estado  = 0 ;

               /* Calcular tamanho compilado do string */

                  inxCh   = 0 ;
                  ContaCh = 0 ;
                  Estado  = EstadoInicial ;

                  while ( inxCh < tamString ) {

                  /* Handle current character */

                     switch( Estado ) {

                     /* Tratar caractere aspas inicial */

                        case EstadoInicial :
                        {

                           if ( StringLido[ inxCh ] != '\"' )
                           {
                              printf( "\n>>> Constante string n�o inicia com aspas: %s" ,
                                  StringLido ) ;
                              ContaErros++ ;
                              inxCh-- ;
                           } /* if */
                           Estado = EstadoNormal ;

                           break ;

                        } /* fim ativa: Tratar caractere aspas inicial */

                     /* Tratar caractere normal */

                        case EstadoNormal :
                        {

                           if ( StringLido[ inxCh ] == '\\' )
                           {
                              ContaCh ++ ;
                              Estado = EstadoEscape ;

                           } else if ( StringLido[ inxCh ] == '\"' )
                           {
                              if ( tamString - 1 == inxCh )
                              {
                                 StringLido[ inxCh ] = 0 ;
                              } else
                              {
                                 printf( "\n>>> Aspas no meio do string: %s" , StringLido ) ;
                                 ContaErros ++ ;

                                 StringLido[ inxCh ] = '?' ;
                                 ContaCh ++ ;
                              } /* if */

                           } else if ( StringLido[ inxCh ] == 0 )
                           {
                              printf( "\n>>>  Falta aspas final: %s" , StringLido ) ;
                              ContaErros ++ ;
                              tamString = inxCh ; // break out

                           } else
                           {
                              ContaCh ++ ;
                           } /* if */

                           break ;

                        } /* fim ativa: Tratar caractere normal */

                     /* Tratar escape */

                        case EstadoEscape :
                        {

                           if ( ( StringLido[ inxCh ] == 'x' )
                             || ( StringLido[ inxCh ] == 'X' ))
                           {
                              Estado = EstadoHexadecimal ;

                           } else if ( strchr( "01234567" , StringLido[ inxCh ] ) != NULL )
                           {
                              Estado = EstadoOctal ;

                           } else if ( strchr( "abfnrtv\'\"\\?" , StringLido[ inxCh ] ) != NULL )
                           {
                              Estado = EstadoNormal ;

                           } else
                           {
                              printf( "\n>>> Sequencia escape mal formada: %s" , StringLido ) ;
                              ContaErros ++ ;
                              Estado   = EstadoNormal ;
                           } /* if */

                           break ;

                        } /* fim ativa: Tratar escape */

                     /* Tratar escape defini��o octal */

                        case EstadoOctal :
                        {

                           Estado = EstadoNormal ;

                           if ( strchr( "01234567" , StringLido[ inxCh ] ) == NULL )
                           {
                              inxCh -- ;    /* reler o caractere */
                              break ;
                           }

                           inxCh ++ ;
                           if ( strchr( "01234567" , StringLido[ inxCh ] ) == NULL )
                           {
                              inxCh -- ;    /* reler o caractere */
                           }

                           break ;

                        } /* fim ativa: Tratar escape defini��o octal */

                     /* Tratar escape hexadecimal */

                        case EstadoHexadecimal :
                        {

                           if ( strchr( "0123456789abcdefABCDEF" , StringLido[ inxCh ] ) == NULL )
                           {
                              Estado = EstadoNormal ;
                              inxCh -- ;
                           }
                           break ;

                        } /* fim ativa: Tratar escape hexadecimal */

                     /* Handle illegal field */

                        default :
                        {

                           printf( "\n>>> Estado desconhecido: %d" , Estado ) ;
                           ContaErros++ ;

                           return ;

                        } /* fim ativa: Handle illegal field */

                     } /* fim seleciona: Handle current character */

                  /* Avan�ar para o pr�ximo caractere */

                     inxCh ++ ;

                  } /* fim repete: Calcular tamanho compilado do string */

               /* Registrar o string na lista ordenada por idString */

                  #ifdef _DEBUG
                     OffsetLido  cont�m o offset a ser adicionado a todos os ids de strings
                                 do corrente arquivo
                     ContaCh     cont�m o tamanho do string em mem�ria (depois de compilado)
                     StringLido  cont�m o string original, com aspas inicial e
                                 sem aspas final
                  #endif

                  idStringLido += OffsetLido ;

                  pStringCorr  = pOrigemListaStrings ;

                  while ( pStringCorr->pProx != NULL )
                  {
                     if ( pStringCorr->pProx->idString > idStringLido )
                     {
                        break ;
                     } else if ( pStringCorr->pProx->idString == idStringLido )
                     {
                        printf( "\n>>> Identificacao de string duplicada: %s" ,
                                LinhaString ) ;
                        ContaErros ++ ;
                        break ;
                     } /* if */

                     pStringCorr = pStringCorr->pProx ;
                  } /* while */

                  pStringNovo = CriarElemListaString(
                                      idStringLido , ContaCh , StringLido + 1 ) ;
                  ContaEspecString ++ ;

                  pStringNovo->pAnt   = pStringCorr ;
                  pStringNovo->pProx  = pStringCorr->pProx ;
                  pStringCorr->pProx  = pStringNovo ;
                  if ( pStringNovo->pProx != NULL )
                  {
                     pStringNovo->pProx->pAnt = pStringNovo ;
                  } /* if */

            } /* fim ativa: Processar linha de especifica��o */

         /* Obter a pr�xima especifica��o de string */

            CondRet = LerTrimmed( pArquivoString , LinhaString ,
                                  DIM_BUFFER - 1 , LIMPA_INIC | LIMPA_FIM ) ;

         } /* fim repete: Obter todos os strings do arquivo corrente */

      /* Terminar processamento do arquivo de especifica��o de strings */

         if ( CondRet != CondRetFimArq )
         {
            printf( "\n>>> Litura do arquivo string % cancelada." ,
                    NomeArquivoString ) ;
            ContaErros ++ ;
         } /* if */

         fclose( pArquivoString ) ;

   } /* Fim fun��o: GT Extrair todos os strings de arquivo de defini��o de strings */


/***********************************************************************
*
*  $FC Fun��o: GT Gerar arquivo tabela de strings
*
***********************************************************************/

   void GerarTabelaStrings( )
   {

      tpElemArquivo * pArquivoCorr = NULL ;

      tpElemString * pStringCorr  = NULL ;

      int tamCorr     = 0 ;
      int ContaTabela = 0 ;

      int inxTabela = -1 ;

      int i ;

      FILE * pArquivoTabela = NULL ;

      /* Abrir arquivo tabela de strings */

         pArquivoTabela = fopen( NomeArquivoTabela , "w" ) ;

         if ( pArquivoTabela == NULL )
         {
            printf( "\n>>> Arquivo tabela  %s  n�o abre." , NomeArquivoTabela ) ;
            ContaErros ++ ;
            return ;
         } /* if */

      /* Gerar coment�rios do cabe�alho do arquivo */

         /* Gerar coment�rio pre�mbulo do arquivo gerado */

            fprintf( pArquivoTabela ,
                       "#ifndef _tabela_string_" ) ;
            fprintf( pArquivoTabela ,
                     "\n#define _tabela_string_" ) ;
            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n/* !!!!!!!!!! Aquivo gerado! N�o o edite! !!!!!!!!!! */" ) ;
            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n/****************************************************************************" ) ;
            fprintf( pArquivoTabela ,
                     "\n*" ) ;
            fprintf( pArquivoTabela ,
                     "\n* $AT Tabela de strings gerada" ) ;
            fprintf( pArquivoTabela ,
                     "\n*" ) ;
            fprintf( pArquivoTabela ,
                     "\n* Arquivo gerado: %s" , NomeArquivoTabela ) ;
            fprintf( pArquivoTabela ,
                     "\n*" ) ;
            fprintf( pArquivoTabela ,
                     "\n* Projeto: INF 1301/1628 Exemplos" ) ;
            fprintf( pArquivoTabela ,
                     "\n* Gestor:  LES/DI/PUC-Rio" ) ;

         /* Gerar lista de arquivos processados */

            fprintf( pArquivoTabela ,
                     "\n*" ) ;
            fprintf( pArquivoTabela ,
                     "\n* Arquivos de especifica��o de strings utilizados para gerar a tabela:" ) ;
            fprintf( pArquivoTabela ,
                     "\n*" ) ;

            pArquivoCorr = pOrigemListaArquivos->pProx ;

            while ( pArquivoCorr != NULL )
            {
               fprintf( pArquivoTabela ,
                        "\n*      - %s" , pArquivoCorr->NomeArquivo ) ;
               pArquivoCorr = pArquivoCorr->pProx ;
            } /* while */

         /* Gerar finaliza��o do coment�rio de abertura */

            fprintf( pArquivoTabela ,
                     "\n*" ) ;
            fprintf( pArquivoTabela ,
                     "\n***************************************************************************/" ) ;

      /* Gerar tabela de pesquisa */

         /* Gerar declara��o do tipo tabela de pesquisa */

            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n#define  DIM_TABELA_STRING  %d" , ContaEspecString ) ;
            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n/* Descritor dos elementos da tabela de pesquisa */" ) ;
            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n   typedef struct" ) ;
            fprintf( pArquivoTabela ,
                     "\n   {" ) ;
            fprintf( pArquivoTabela ,
                     "\n      long idString        ;" ) ;
            fprintf( pArquivoTabela ,
                     "\n      int  tamString       ; /* tamanho strlen do string */" ) ;
            fprintf( pArquivoTabela ,
                     "\n      int  inxSubTabela    ; /* identifica o vetor de texto*/" ) ;
            fprintf( pArquivoTabela ,
                     "\n      int  inxOrigemString ; /* origem no vetor de texto*/" ) ;
            fprintf( pArquivoTabela ,
                     "\n   } tpElementoTabela ;" ) ;

         /* Gerar daclara��o cabe�alho da tabela de pesquisa */

            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n/* Tabela de pesquisa" ) ;
            fprintf( pArquivoTabela ,
                     "\n*     Cada elemento corresponde a um string" ) ;
            fprintf( pArquivoTabela ,
                     "\n*     Strings s�o procurados pelo correspondente id." ) ;
            fprintf( pArquivoTabela ,
                     "\n*     Cada elemento referencia para um vetor de caracteres contendo o" ) ;
            fprintf( pArquivoTabela ,
                     "\n*     string. Fornecendo, ainda, o offset de in�cio do string neste vetor.*/" ) ;
            fprintf( pArquivoTabela ,
                     "\n" ) ;
            fprintf( pArquivoTabela ,
                     "\n   static tpElementoTabela vtTabelaPesquisa[ DIM_TABELA_STRING ] =" ) ;
            fprintf( pArquivoTabela ,
                     "\n   {" ) ;

         /* Gerar corpo da tabela de pesquisa */

            pStringCorr  = pOrigemListaStrings->pProx ;

            tamCorr      = 0 ;
            ContaTabela  = 0 ;

            while ( pStringCorr != NULL )
            {
               if ( tamCorr + pStringCorr->tamString >= DIM_STRINGAO )
               {
                  ContaTabela ++ ;
                  tamCorr = 0 ;
               } /* if */

               pStringCorr->inxString    = ContaTabela ;
               pStringCorr->offsetString = tamCorr ;
               tamCorr                  += pStringCorr->tamString + 1 ;

               fprintf( pArquivoTabela ,
                        "\n      { %8li , %5i , %5i , %5i }" ,
                        pStringCorr->idString  , pStringCorr->tamString ,
                        pStringCorr->inxString , pStringCorr->offsetString ) ;

               if ( pStringCorr->pProx != NULL )
               {
                  fprintf( pArquivoTabela , " ," ) ;
               } else
               {
                  fprintf( pArquivoTabela , "  " ) ;
               } /* if */

               fprintf( pArquivoTabela , " /* \"%s\" */" ,
                        pStringCorr->String ) ;

               pStringCorr = pStringCorr->pProx ;
            } /* while */

            fprintf( pArquivoTabela ,
                     "\n   } ; /* Fim tabela de pesquisa */" ) ;

      /* Gerar vetores de caracteres */

         fprintf( pArquivoTabela ,
                  "\n" ) ;
         fprintf( pArquivoTabela ,
                  "\n/* Vetores de strings" ) ;
         fprintf( pArquivoTabela ,
                  "\n*  Cada vetor cont�m um ou mais strings terminados em zero" ) ;
         fprintf( pArquivoTabela ,
                  "\n*  Cada vetor cont�m no m�ximo %d bytes */" ,
                  DIM_STRINGAO ) ;

         inxTabela = -1 ;

         pStringCorr  = pOrigemListaStrings->pProx ;

         while ( pStringCorr != NULL )
         {
            if ( inxTabela != pStringCorr->inxString )
            {
               if ( inxTabela >= 0 )
               {
                  fprintf( pArquivoTabela ,
                           "\n   ; /* Fim vetor %d */" , inxTabela ) ;
               } /* if */
               inxTabela = pStringCorr->inxString ;
               fprintf( pArquivoTabela , "\n" ) ;
               fprintf( pArquivoTabela ,
                        "\n   static char Stringao_%d[ ] = " , inxTabela ) ;
            } /* if */

            fprintf( pArquivoTabela ,
                     "\n      \"%s\\0\"" , pStringCorr->String ) ;

            pStringCorr = pStringCorr->pProx ;
         } /* while */

         fprintf( pArquivoTabela ,
                  "\n   ; /* Fim vetor %d */" , inxTabela ) ;

      /* Gerar vetor de refer�ncias a vetores de strings */

         fprintf( pArquivoTabela ,
                  "\n" ) ;
         fprintf( pArquivoTabela ,
                  "\n/* Vetor de refer�ncias a vetores de strings */" ) ;
         fprintf( pArquivoTabela ,
                  "\n" ) ;
         fprintf( pArquivoTabela ,
                  "\n   static char * vtpStringoes[ %i ] = " , ContaTabela + 1 ) ;
         fprintf( pArquivoTabela ,
                  "\n        {" ) ;

         for ( i = 0 ; i <= ContaTabela ; i++ )
         {
            fprintf( pArquivoTabela , " Stringao_%i" , i ) ;
            if ( i < ContaTabela )
            {
               fprintf( pArquivoTabela , " ," ) ;
            } /* if */
         } /* for */

         fprintf( pArquivoTabela , " } ;" ) ;

      /* Gerar t�rmino da tabela de strings */

         fprintf( pArquivoTabela ,
                  "\n" ) ;
         fprintf( pArquivoTabela ,
                  "\n#endif" ) ;
         fprintf( pArquivoTabela ,
                  "\n" ) ;
         fprintf( pArquivoTabela ,
                  "\n/* Fim tabela strings gerada */" ) ;
         fprintf( pArquivoTabela ,
                  "\n" ) ;

         fclose( pArquivoTabela ) ;

   } /* Fim fun��o: GT Gerar arquivo tabela de strings */


/***********************************************************************
*
*  $FC Fun��o: GT Gerar arquivo de estat�sticas
*
*  $ED Descri��o da fun��o
*     Gera um arquivo de estat�sticas para fins de automa��o dos testes
*
***********************************************************************/

   void GerarEstatisticas( )
   {

      FILE * pArquivoEstatisticas = NULL ;

      pArquivoEstatisticas = fopen( NomeArquivoEstatisticas , "w" ) ;

      if ( pArquivoEstatisticas != NULL )
      {
         fprintf( pArquivoEstatisticas , "NumArquivosString: %7d\n" ,
                        ContaArquivosString ) ;
         fprintf( pArquivoEstatisticas , "NumStrings:        %7d\n" ,
                        ContaEspecString ) ;
         fprintf( pArquivoEstatisticas , "NumVetoresString:  %7d\n" ,
                        ContaStringao + 1 ) ;
         fprintf( pArquivoEstatisticas , "NumErros:          %7d\n" ,
                        ContaErros ) ;
         fclose( pArquivoEstatisticas ) ;
      } else
      {
         printf( "\n>>> Arquivo estatisticas  %s  n�o abre." ,
                 NomeArquivoEstatisticas ) ;
         ContaErros ++ ;
      } /* if */

   } /* Fim fun��o: GT Gerar arquivo de estat�sticas */


/***********************************************************************
*
*  $FC Fun��o: GT Criar elemento de lista string
*
***********************************************************************/

   tpElemString * CriarElemListaString( long   idStringParm ,
                                        int    tamStringParm ,
                                        char * StringParm )
   {

      int tamString = 0 ;
      tpElemString * pElemString = NULL ;

      pElemString = ( tpElemString * ) malloc( sizeof( tpElemString )) ;

      tamString = strlen( StringParm ) ;
      if ( tamString >= DIM_STRING )
      {
         tamString = DIM_STRING - 1 ;
         printf( "\n>>> String longo demais: %s" , StringParm ) ;
         StringParm[ tamString ] = 0 ;
         ContaErros ++ ;
      } /* if */

      pElemString->pAnt         = NULL ;
      pElemString->pProx        = NULL ;

      memchr( pElemString->String , 0 , DIM_STRING ) ;
      strcpy( pElemString->String , StringParm ) ;

      pElemString->idString     = idStringParm ;
      pElemString->tamString    = tamStringParm ;
      pElemString->inxString    = 0 ;
      pElemString->offsetString = 0 ;

      return pElemString ;

   } /* Fim fun��o: GT Criar elemento de lista string */


/***********************************************************************
*
*  $FC Fun��o: GT Criar elemento de lista de arquivos
*
***********************************************************************/

   tpElemArquivo * CriarElemListaArquivo( char * NomeArquivoParm )
   {

      tpElemArquivo * pElemArquivo = NULL ;

      pElemArquivo = ( tpElemArquivo * ) malloc( sizeof( tpElemArquivo )) ;
      pElemArquivo->pAnt  = NULL ;
      pElemArquivo->pProx = NULL ;
      strcpy( pElemArquivo->NomeArquivo , NomeArquivoParm ) ;

      return pElemArquivo ;

   } /* Fim fun��o: GT Criar elemento de lista de arquivos */


/***********************************************************************
*
*  $FC Fun��o: GT Inserir arquivo na lista ordenada por nome
*
*  $EP Par�metros
*     pArquivoNovo - elemento arquivo a ser inserido na lista
*
*  $FV Valor retornado
*     0 se arquivo j� estava registrado
*     1 se n�o
*           destr�i o elemento n�o inserido na lista
*
*  $FGP Tipos e Vari�veis globais externas do pr�prio m�dulo
*     pOrigemListaArquivos - aponta para a cabe�a da lista de arquivos
*
***********************************************************************/

   int RegistrarArquivo( char * NomeArquivo )
   {

      tpElemArquivo * pArquivoNovo  = NULL ;
      tpElemArquivo * pArquivoCorr  = NULL ;

      #ifdef _DEBUG
         A cabe�a da lista � um elemento normal.
      #endif

      pArquivoCorr = pOrigemListaArquivos ;

      while ( pArquivoCorr->pProx != NULL )
      {
         if ( strcmp( pArquivoCorr->pProx->NomeArquivo , NomeArquivo ) > 0 )
         {
            break ;

         } else if ( strcmp( pArquivoCorr->pProx->NomeArquivo , NomeArquivo ) == 0 )
         {
            printf( "\n>>> Arquivo string duplicado: %s" , NomeArquivo ) ;
            ContaErros ++ ;

            return 0 ;

         } /* if */

         pArquivoCorr = pArquivoCorr->pProx ;

      } /* while */

      pArquivoNovo = CriarElemListaArquivo( NomeArquivo ) ;

      pArquivoNovo->pAnt  = pArquivoCorr ;
      pArquivoNovo->pProx = pArquivoCorr->pProx ;
      pArquivoCorr->pProx = pArquivoNovo ;
      if ( pArquivoNovo->pProx != NULL )
      {
         pArquivoNovo->pProx->pAnt = pArquivoNovo ;
      } /* if */

      return 1 ;

   } /* Fim fun��o: GT Inserir arquivo na lista ordenada por nome */


/***********************************************************************
*
*  $FC Fun��o: GT Obter �ndice do nome de extens�o
*
*  $EP Par�metros
*     NomeArquivo - nome do arquivo a examinar
*
*  $FV Valor retornado
*     Indice do caractere '.' separador do nome de extens�o
*        ser� -1 caso o nome de extens�o n�o exista
*
***********************************************************************/

   int ObterInxExtensao( char * NomeArquivo )
   {

      int Encontrou ,
          i ;

      Encontrou = -1 ;

      for( i = strlen( NomeArquivo ) - 1 ; i > 0  ; i -- )
      {
         if ( NomeArquivo[ i ] == SEPARADOR_EXTENSAO )
         {
            Encontrou = i ;
            break ;

         } else if ( NomeArquivo[ i ] == SEPARADOR_DIRETORIO )
         {
            break ;

         } /* if */
      } /* for */

      return Encontrou ;

   } /* Fim fun��o: GT Obter �ndice do nome de extens�o */


/***********************************************************************
*
*  $FC Fun��o: GT Ler eliminando brancos no in�cio e no final
*
*  $ED Descri��o da fun��o
*     L� uma linha, eliminando os caracteres "branco" no in�cio e no final
*     Salta linhas de coment�rio
*     Linhas nulas ap�s elimina��o de brancos s�o saltadas
*
*  $EP Par�metros
*     pArqLe     - ponteiro para descritor de arquivo de leitura
*     pBuffer    - ponteiro para a �rea de leitura
*     dimBuffer  - dimens�o do buffer
*     Modo       - modo de limpeza, qualquer combina��o ( OR ) de 0,1 ou 2
*                  das condi��es a seguir :
*                      LIMPA_INIC - limpa antes
*                      LIMPA_FIM  - limpa no final
*
*  $FV Valor retornado
*     CondRetOK     - leu um buffer v�lido
*
*     CondRetFimArq - encontrou fim de arquivo
*                     Buffer cont�m string nulo
*
*     CondRetErro   - erro permanente de leitura
*                     Buffer cont�m string nulo
*
***********************************************************************/

   tpCondRet LerTrimmed( FILE * pArqLe    ,
                         char * pBuffer   ,
                         int    dimBuffer ,
                         int    Modo       )
   {

      int Continua = 0 ;
      int i        = 0 ;

      int tamLinha ;

      /* Controlar final de arquivo */

         if ( feof( pArqLe ))
         {

            pBuffer[ 0 ] = 0 ;
            return CondRetFimArq ;

         } /* fim ativa: Controlar final de arquivo */

      /* Procurar linha n�o vazia */

         Continua = 1 ;

         while ( Continua ) {

         /* Ler linha de arquivo */

            pBuffer[ dimBuffer - 1 ] = '@' ;

            if ( fgets( pBuffer , dimBuffer , pArqLe ) == NULL )
            {
               pBuffer[ 0 ] = 0 ;
               if ( feof( pArqLe ))
               {
                  return CondRetFimArq ;
               } else {
                  return CondRetErro ;
               } /* if */
            } /* if */

            if ( pBuffer[ dimBuffer - 1 ] != '@' )
            {
               printf( "\n>>> Linha longa demais" ) ;
               ContaErros ++ ;
               return CondRetOverflow ;
            } /* if */

         /* Limpar a linha */

            /* Eliminar lixo no final */

               if ( Modo & LIMPA_FIM )
               {

                  tamLinha = ( int ) strlen( pBuffer ) ;
                  for( i = tamLinha - 1 ; i >= 0 ; i -- )
                  {
                     if ( strchr( CHARS_FIM , pBuffer[ i ] ) == NULL )
                     {
                        break ;
                     } /* if */
                  } /* for */

                  i++ ;
                  pBuffer[ i ] = 0 ;

               } /* fim ativa: Eliminar lixo no final */

            /* Eliminar lixo no in�cio */

               if ( Modo & LIMPA_INIC )
               {

                  tamLinha = ( int ) strlen( pBuffer ) ;
                  for( i = 0 ; i < tamLinha ; i++ )
                  {
                     if ( pBuffer[ i ] != ' ' )
                     {
                        break ;
                     } /* if */
                  } /* for */

                  if ( i > 0 )
                  {
                     strcpy( pBuffer , pBuffer + i ) ;
                  } /* if */

               } /* fim ativa: Eliminar lixo no in�cio */

         /* Determinar o que fazer com a linha */

            Continua = 0 ;

            if ( ( memcmp( pBuffer , ID_COMENTARIO , strlen( ID_COMENTARIO )) == 0 )
              || ( strlen( pBuffer ) == 0 ))
            {
               Continua = 1 ;
            } /* if */

         } /* fim repete: Procurar linha n�o vazia */

      return CondRetOK ;

   } /* Fim fun��o: GT Ler eliminando brancos no in�cio e no final */

/********** Fim do m�dulo de implementa��o: GTB Gerar a tabela de strings residentes **********/

